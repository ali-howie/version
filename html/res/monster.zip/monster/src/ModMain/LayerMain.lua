require("VisibleRect")

module(..., package.seeall)

local layer = nil
local pao = nil
local paoHuo = nil
local posBegin = nil

function onTouchBegan(touch, event)
    local target = event:getCurrentTarget()
    local point = target:getParent():convertTouchToNodeSpace(touch)

    if cc.rectContainsPoint(target:getBoundingBox(), point) then
        posBegin = point
        return true
    else
        return false
    end
end

function onTouchMoved(touch, event)
    local target = event:getCurrentTarget()
    local point = target:getParent():convertTouchToNodeSpace(touch)

    local value = 0
    local v = math.abs(point.x-posBegin.x)/50
    if point.x<posBegin.x  then
        value = v+pao:getRotation()
    else
        value =pao:getRotation()-v
    end

    if value>75 then
        value = 75
    elseif value<-75 then
        value = -75
    end
    pao:setRotation(value)
end

function onTouchEnded(touch, event)
    pao:getAnimation():play("cannon")
    paoHuo:getAnimation():play('start')

    local paodan = cc.Sprite:create("main/paodan_1.png")
    local size = pao:getContentSize()

    --    paodan:setRotation(pao:getRotation())
    paodan:setPosition(pao:getPosition())
    paodan:setPhysicsBody(cc.PhysicsBody:createBox(paodan:getContentSize()))
    paodan:getPhysicsBody():setCategoryBitmask(1)
    paodan:getPhysicsBody():setCollisionBitmask(4)
    paodan:getPhysicsBody():setContactTestBitmask(-1);
    layer:addChild(paodan)
    paodan:runAction(cc.RepeatForever:create(cc.MoveBy:create(0.5, cc.p(0, 150))))
end

function addMonster(pos)
    local boss = ccs.Armature:create("Boss")
    boss:setPosition(pos)
    boss:setLocalZOrder(1)
    boss:getAnimation():play('boss_zou')
    layer:addChild(boss)
    local action = cc.MoveTo:create(10, cc.p(boss:getPositionX(), VisibleRect:bottom().y+80))
    boss:runAction(action)
    boss:setPhysicsBody(cc.PhysicsBody:createBox(boss:getContentSize()))
    boss:getPhysicsBody():setCategoryBitmask(4)
    boss:getPhysicsBody():setCollisionBitmask(1)
    boss:getPhysicsBody():setContactTestBitmask(-1)
end

function dataLoaded(percent)
    if percent>=1 then
        addMonster(VisibleRect:top())
        --        for i=1, 2 do
        --            addMonster(cc.p(i*225, VisibleRect:top().y))
        --        end
        pao = ccs.Armature:create("Pao")
        pao:setLocalZOrder(1)
        pao:getAnimation():play("default")
        local listener = cc.EventListenerTouchOneByOne:create()
        listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
        listener:registerScriptHandler(onTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
        listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
        pao:getEventDispatcher():addEventListenerWithSceneGraphPriority(listener, pao)
        pao:setPosition(VisibleRect:bottom().x, VisibleRect:bottom().y+280)
        pao:setPhysicsBody(cc.PhysicsBody:createBox(pao:getContentSize()))
        pao:getPhysicsBody():setCategoryBitmask(2)
        pao:getPhysicsBody():setCollisionBitmask(2)
        pao:getPhysicsBody():setContactTestBitmask(2)
        layer:addChild(pao)

        paoHuo = ccs.Armature:create("paoHuo")
        local size = pao:getContentSize()
        paoHuo:setPosition(0, size.height/2-20)
        pao:addChild(paoHuo)
    end
end

function onEnter()
    print(string.format("LayerMain.onEnter"))
    local rootNode = ccs.NodeReader:getInstance():createNode("main.json")
    layer:addChild(rootNode)

    ccs.ArmatureDataManager:getInstance():addArmatureFileInfoAsync("main/Boss0.png", "main/Boss0.plist", "main/Boss.ExportJson", dataLoaded)
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfoAsync("main/Pao0.png", "main/Pao0.plist", "main/Pao.ExportJson", dataLoaded)
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfoAsync("main/paoHuo0.png", "main/paoHuo0.plist", "main/paoHuo.ExportJson", dataLoaded)
end

function onExit()
end

function onEnterOrExit(tag)
    if tag=="enter" then
        onEnter()
    elseif tag =="exit" then
        onExit()
    end
end

function create()
    layer = ts.BaseLayer:create()
    layer:registerScriptHandler(onEnterOrExit)

    return layer
end