require("LayerMain")
require("VisibleRect")

module(..., package.seeall)

function onEnter()
    print(string.format("SceneMain.onEnter"))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function doRemoveFromParentAndCleanup(sender,table)
    sender:removeFromParent()
end

function onContactBegin(contact)
    local a = contact:getShapeA():getBody()
    local b = contact:getShapeB():getBody()

--    a:getNode():runAction(cc.Sequence:create(cc.FadeOut:create(0.2), cc.CallFunc:create(doRemoveFromParentAndCleanup,{true})))
--    b:getNode():runAction(cc.Sequence:create(cc.FadeOut:create(0.2), cc.CallFunc:create(doRemoveFromParentAndCleanup,{true})))
    a:getNode():runAction(cc.CallFunc:create(doRemoveFromParentAndCleanup,{true}))
    b:getNode():runAction(cc.CallFunc:create(doRemoveFromParentAndCleanup,{true}))
    LayerMain.addMonster(VisibleRect:top())
    return true;
end

function create()
    local scene = ts.BaseScene:createWithPhysics()
    scene:registerScriptHandler(onEnterOrExit)
    --    scene:getPhysicsWorld():setGravityEnable(false);
    scene:getPhysicsWorld():setGravity(cc.p(0, 0))
--    scene:getPhysicsWorld():setDebugDrawMask(true and cc.PhysicsWorld.DEBUGDRAW_ALL or cc.PhysicsWorld.DEBUGDRAW_NONE)

    local contactListener = cc.EventListenerPhysicsContact:create();
    contactListener:registerScriptHandler(onContactBegin, cc.Handler.EVENT_PHYSICS_CONTACT_BEGIN);
    local eventDispatcher = scene:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(contactListener, scene);

    local layer = LayerMain:create();
    scene:addChild(layer)

    return scene
end
