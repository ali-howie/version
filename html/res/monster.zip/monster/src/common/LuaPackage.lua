require("extern")

LuaPackage = class("LuaPackage")
LuaPackage.__index = LuaPackage

function LuaPackage:init()
    require("Cocos2d")
    require("Cocos2dConstants")
    require("GuiConstants")
    require("VisibleRect")
    require("GameConstants")
    require("Utils")
    require("json")
end

function LuaPackage:reload()
    local path = cc.FileUtils:getInstance():fullPathForFilename("src");
    local files = ts.FileUtility:getDirsFilesAtPath(path);

    for key, value in pairs(files) do
        if string.find(value, ".lua") then
            local name = string.gsub(value, ".lua", "")
            _G[name] = nil
            package.loaded[name] = nil
        end
    end
    
    ccs.NodeReader:getInstance():purge()
    cc.Director:getInstance():purgeCachedData()
    
    self:init()
end