require "extern"

Utils = class("Utils")
Utils.__index = Utils

function Utils:ParamsToString(params)
    local str = ""
    if type(params) ~= "table" then
        print("Utils:ParamsToString params not table")
        str = ""
    else
        for key, value in pairs(params) do
            if str=="" then
                str = str..key.."="..value
            else
                str = str.."&"..key.."="..value
            end
        end
    end

    return str
end