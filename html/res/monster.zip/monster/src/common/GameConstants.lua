--Encapsulate opengl constants. 
GameConstants = GameConstants or {} 

GameConstants.SERVER_URL = "server_url"