function createScene(name)
    local scene = require(name)
    return scene.create()
end

function cclog(...)
    print(string.format(...))
end

function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
    return msg
end

local function main()
    collectgarbage("collect")
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    local fileUtils = cc.FileUtils:getInstance()   
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/res"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/res/anim"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/res/fonts"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/res/images"))
    
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/src/common"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/src/ModLaunch"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/src/ModMain"))
    fileUtils:addSearchPath(fileUtils:fullPathForFilename("monster/src/ModUpdate"))
    
    require("LuaPackage")
    LuaPackage:init()
    
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(createScene("SceneLaunch"))
    else
        cc.Director:getInstance():runWithScene(createScene("SceneLaunch"))
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
