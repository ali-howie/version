require("LayerLaunch")

module(..., package.seeall)

function onEnter()
    print(string.format("SceneLaunch.onEnter"))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    local scene = ts.BaseScene:create()

    local layer = LayerLaunch:create();
    scene:addChild(layer)
    
    return scene
end