require("LayerLaunch")

module(..., package.seeall)

function onEnter()
    print(string.format("SceneLaunch.onEnter"))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    local scene = ts.BaseScene:create()

    local layer = LayerLaunch:create();
    scene:addChild(layer)
    
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(scene, "cc.Ref"), onNativeCallBack, cc.Handler.CALLFUNC)

    return scene
end

function onNativeCallBack(data)
    if data then
        data = tolua.cast(data, "LuaData");
        LayerLaunch[data:getFuncName()](ts.StringUtility:split(data:getFuncData(), "@_@"))
    end
end
