module(..., package.seeall)

local layer = nil
local beginGameBtn = nil

function onClick(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        if sender:getTag()==41 then
            cc.Director:getInstance():replaceScene(createScene("SceneMain"))
        end
    end
end

function onEnter()
    local rootNode = ccs.NodeReader:getInstance():createNode("launch.json")
    layer:addChild(rootNode)

    local panel = rootNode:getChildren()[1]
    beginGameBtn = panel:getChildByName("beginGameBtn")
    if beginGameBtn ~= nil then
        beginGameBtn:addTouchEventListener(onClick)
    end
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    layer = ts.BaseLayer:create()
    layer:registerScriptHandler(onEnterOrExit)

    return layer
end

function onHttpProgress(data)
end

function onHttpFinish(data)
end