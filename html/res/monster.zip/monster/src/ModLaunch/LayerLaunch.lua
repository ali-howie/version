module(..., package.seeall)

local layer = nil
local localVersionCode = nil
local beginGameBtn = nil
local versionCheckPromptLabel = nil

function onClick(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        if sender:getTag()==41 then
            cc.Director:getInstance():replaceScene(createScene("SceneMain"))
            --        elseif sender:getTag()==69 then
            --            cc.Director:getInstance():replaceScene(createScene("SceneUpdate"))
        end
    end
end

function onEnter()
    local rootNode = ccs.NodeReader:getInstance():createNode("launch.json")
    layer:addChild(rootNode)

    local panel = rootNode:getChildren()[1]
    beginGameBtn = panel:getChildByName("BeginGameBtn")
    if beginGameBtn ~= nil then
        beginGameBtn:addTouchEventListener(onClick)
    end

    versionCheckPromptLabel = panel:getChildByName("LabelBMFont_7")

    local vetsionLabel = panel:getChildByName("LabelBMFont_6")
    localVersionCode = tonumber(cc.UserDefault:getInstance():getStringForKey("VERSION_CODE"))
    local a = math.modf(localVersionCode/10000)
    local b = math.modf(localVersionCode%10000/100)
    local c = localVersionCode%100
    vetsionLabel:setString("V"..a.."."..b.."."..c)

    local dataCache = ts.DataCache:getInstance()
    local param = {}
    param["client_id"] = dataCache:getClientID()
    param["client_secret"] = dataCache:getClientSecret()
    param["version_code"] = localVersionCode

    cc.Director:getInstance():getRunningScene():doGetGameGateAsyncRequestByLua("version", Utils:ParamsToString(param))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    layer = ts.BaseLayer:create()
    layer:registerScriptHandler(onEnterOrExit)

    return layer
end

function onHttpProgress(data)
end

function onHttpFinish(data)
    if type(data)=="table" then
        if data[1]=="ok" then
            local str = string.gsub(data[2], "\\", "")
            local jsonTable = json.decode(str)

            for key, value in pairs(jsonTable) do
                cclog("%s->%s", key, value);
            end

            if jsonTable["error_code"]==nil then
                versionCheckPromptLabel:setVisible(false)
                beginGameBtn:setVisible(true)
            else
                print("error_code:"..jsonTable["error_code"])
            end
        end
    end
end