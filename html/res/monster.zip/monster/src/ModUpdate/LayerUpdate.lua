require("VisibleRect")

module(..., package.seeall)

local layer = nil
local progressLabel = nil
local srcZip = "src.zip"
local resZip = "res.zip"
local srcZipUrl = "http://localhost:8080/res/src.zip"
local resZipUrl = "http://localhost:8080/res/res.zip"

function onClick(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        --back btn
        if sender:getTag()==72 then
            cc.Director:getInstance():replaceScene(createScene("SceneLaunch"))
        elseif sender:getTag()==70 then
            --update btn
            cc.Director:getInstance():getRunningScene():doDownloadByLua(srcZipUrl, srcZip)
        end
    end
end

function onEnter()
    print(string.format("LayerUpdate.onEnter"))
    local rootNode = ccs.NodeReader:getInstance():createNode("update.json")
    local panel = rootNode:getChildren()[1]
    --    local childBtn = ccui.Helper:seekWidgetByTag(panel, 41)
    progressLabel = panel:getChildByName("LabelBMFont_11")

    local childBtn = panel:getChildByName("Button_10")
    if childBtn ~= nil then
        childBtn:addTouchEventListener(onClick)
    end

    local childBtn = panel:getChildByName("Button_12")
    if childBtn ~= nil then
        childBtn:addTouchEventListener(onClick)
    end

    layer:addChild(rootNode)
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    layer = ts.BaseLayer:create()
    layer:registerScriptHandler(onEnterOrExit)

    return layer
end

function onHttpProgress(data)
    if data then
        if tonumber(data[2])>0 and tonumber(data[1])>0 then
            local progress = ts.StringUtility:parse(data[2]/data[1]*100, 0)
            progressLabel:setString(progress.."%")
        end
    end
end

function onHttpFinish(data)
    if type(data)=="table" then
        for key, value in pairs(data) do
            cclog("%s->%s", key, value);
        end
        progressLabel:setString("100%")
        
--        local path = cc.FileUtils:getInstance():getWritablePath()
--        cc.Director:getInstance():getRunningScene():doUnzipFileByLua(path..zipName, path)
    end
end

function onZipProgress(data)
    if data then
        if tonumber(data[2])>0 and tonumber(data[1])>0 then
            local progress = ts.StringUtility:parse(data[2]/data[1]*100, 0)
            progressLabel:setString("Unzip："..progress.."%")
        end
    end
end

function onZipFinish(data)
    if type(data)=="table" then
        for key, value in pairs(data) do
            cclog("%s->%s", key, value);
        end
        progressLabel:setString("Unzip success")
--        LuaPackage:reload()
    end
end