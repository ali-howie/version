require("LayerUpdate")

module(..., package.seeall)

function onEnter()
    print(string.format("SceneUpdate.onEnter"))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function onNativeCallBack(data)
    if data then
        data = tolua.cast(data, "LuaData");
        LayerUpdate[data:getFuncName()](ts.StringUtility:split(data:getFuncData(), "@_@"))
    end
end

function create()
    local scene = ts.BaseScene:create()
    scene:registerScriptHandler(onEnterOrExit)
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(scene, "cc.Ref"), onNativeCallBack, cc.Handler.CALLFUNC)

    local layer = LayerUpdate:create();
    scene:addChild(layer)
    return scene
end
