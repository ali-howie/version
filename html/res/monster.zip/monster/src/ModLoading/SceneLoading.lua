require("LayerLoading")

module(..., package.seeall)

function onEnter()
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function onNativeCallBack(data)
    if data then
        data = tolua.cast(data, "LuaData");
        local response = ts.StringUtility:split(data:getFuncData(), "@_@")
        print("Response: "..table.concat(response,", "))
        LayerLoading[data:getFuncName()](response)
    end
end

function create()
    local scene = ts.BaseScene:create()
    scene:registerScriptHandler(onEnterOrExit)
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(scene, "cc.Ref"), onNativeCallBack, cc.Handler.CALLFUNC)

    local layer = LayerLoading:create();
    scene:addChild(layer)
    return scene
end
