module(..., package.seeall)

local layer = nil
local versionCheckPromptLabel = nil
local progressLabel = nil
local vetsionLabel = nil
local localVersionCode = nil
local latestVersionCode = nil
local downloadMd5 = nil
local downloadUrl = nil

function onEnter()
    local rootNode = ccs.NodeReader:getInstance():createNode("loading.json")
    layer:addChild(rootNode)

    local panel = rootNode:getChildren()[1]
    versionCheckPromptLabel = panel:getChildByName("versionCheckPromptLabel")
    progressLabel = panel:getChildByName("progressLabel")
    vetsionLabel = panel:getChildByName("vetsionLabel")

    localVersionCode = tonumber(cc.UserDefault:getInstance():getStringForKey("VERSION_CODE"))
    local a = math.modf(localVersionCode/10000)
    local b = math.modf(localVersionCode%10000/100)
    local c = localVersionCode%100
    vetsionLabel:setString("V"..a.."."..b.."."..c)

    local dataCache = ts.DataCache:getInstance()
    local param = {}
    param["client_id"] = dataCache:getClientID()
    param["client_secret"] = dataCache:getClientSecret()
    param["version_code"] = localVersionCode

    cc.Director:getInstance():getRunningScene():doGetGameGateAsyncRequestByLua("version", Utils:ParamsToString(param))
end

function onExit()
end

function onEnterOrExit(tag)
    if tag == "enter" then
        onEnter()
    elseif tag == "exit" then
        onExit()
    end
end

function create()
    layer = ts.BaseLayer:create()
    layer:registerScriptHandler(onEnterOrExit)

    return layer
end

function onHttpProgress(data)
end

function onHttpFinish(data)
    if data[1]=="ok" then
        local response = data[2]
        local first = string.sub(response, 1, 1)

        if first~="[" and first~="{" then
            if response=="" then
                print("Download success")
                local downloadPath = ts.DataCache:getInstance():getDowloadPath()
                cc.Director:getInstance():getRunningScene():doUnzipFileByLua(downloadPath..downloadMd5, downloadPath)
            end
            return
        end

        local str = string.gsub(response, "\\", "")
        local jsonTable = json.decode(str)

        if jsonTable["error_code"]==nil then
            if jsonTable["path"]=="/version" then
                if jsonTable["download"]~=nil then
                    downloadMd5 = jsonTable["download"][1]["md5"]
                    downloadUrl = jsonTable["download"][1]["url"]
                end

                if jsonTable["latest_version"]~=nil then
                    latestVersionCode = jsonTable["latest_version"]
                    if math.modf(localVersionCode/10000)~=math.modf(tonumber(latestVersionCode)/10000) then
                        --Big version update
                        print("Big version update")
                    elseif tonumber(jsonTable["latest_version"])~=localVersionCode then
                        --Small version update
                        print("Small version update")
                        local downloadFile = ts.DataCache:getInstance():getDowloadPath()..downloadMd5
                        cc.Director:getInstance():getRunningScene():doDownloadByLua(downloadUrl, downloadFile)
                    end
                else
                    --No update
                    print(jsonTable["response"])
                    cc.Director:getInstance():replaceScene(createScene("SceneLaunch"))
                end
            else
            end
        else
            print("error_code:"..jsonTable["error_code"])
        end
    end
end

function onZipProgress(data)
    if data then
        if tonumber(data[2])>0 and tonumber(data[1])>0 then
            local progress = ts.StringUtility:parse(data[2]/data[1]*100, 0)
            progressLabel:setString("Unzip："..progress.."%")
        end
    end
end

function onZipFinish(data)
    if data[1]=="ok" then
        progressLabel:setString("Unzip success")
        ts.FileUtility:removeFile(data[2])
        LuaPackage:reload()
        cc.UserDefault:getInstance():setStringForKey("VERSION_CODE", latestVersionCode)
        print("kkk: "..cc.UserDefault:getInstance():getStringForKey("VERSION_CODE"))
        cc.Director:getInstance():replaceScene(createScene("SceneLaunch"))
    else
    end
end